import React, { useState } from 'react';

export default function SaveStyle(props) {

    const [color ,setColor ] = useState(props.product.situation)

    const changeColor = ()=>{
        if(color == "red"){
            setColor("green")
            props.changeSituation(props.product,color)
        }else{
            setColor("red")
            props.changeSituation(props.product,color)

        }
    }

  return (
    <div>
      <button style={{background:color}} onClick={changeColor} className={"style"} >{props.product.nameProduct}</button>
    </div>
  )
}
