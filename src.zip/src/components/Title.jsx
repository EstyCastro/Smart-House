import React from 'react'

export default function Title() {
  return (
    <div>
      <h1>Smart House</h1>
    </div>
  )
}
